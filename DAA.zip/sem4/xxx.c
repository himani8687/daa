#include <stdio.h>
#include <limits.h>
int m[100][100];
int s[100][100];
void print(int i,int j)
{
    if(i==j)
    {
        printf("A%d",i);
        return;
    }
    printf("(");
    print(i,s[i][j]);
    print(s[i][j]+1,j);
    printf(")");
}
int find(int p[],int n)
{
    for(int i=1;i<n;i++)
    m[i][i]=0;

    for(int len=2;len<n;len++)
    {
        for(int i=1;i<n-len+1;i++)
        {
            int j=i+len-1;
            m[i][j]=INT_MAX;
            for(int k=i;k<j;k++)
            {
                int q=m[i][k]+m[k+1][j]+p[i-1]*p[j]*p[k];
                if(q<m[i][j])
                {
                    m[i][j]=q;
                    s[i][j]=k;
                }
            }
        }
    }

    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
        {
            printf("%d ",m[i][j]);
        }
        printf("\n");
    }
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
        {
            printf("%d ",s[i][j]);
        }
        printf("\n");
    }
}
int main()
{
    int p[]={30,35,15,5,10,20,25};
    int n=7;

    int result=find(p,n);
    print(1,n-1);
    return 0;
}