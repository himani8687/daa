// quick sort
#include <stdio.h>
int find(int *a,int start,int end)
{
    for(int i=star)
}
void quick(int *a,int start,int end)
{
    int pivot=find(a,start,end);

}
int main()
{
    int n,a[100];
    printf("Enter array size : ");
    scanf("%d",&n);
    printf("Enter array elements : ");
    for(int i=0;i<n;i++)
    scanf("%d",&a[i]);

    quick(a,0,n-1);

    printf("Sorted array : ");
    for(int i=0;i<n;i++)
    printf("%d ",a[i]);

    return 0;
}