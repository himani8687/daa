#include <stdio.h>
void swap(int *x,int *y,int *c)
{
    int t=*x;
    *x=*y;
    *y=t;
    *c=0;
}
void sort(int *arr,int *index,int n)
{
    for(int i=n-1;i>=0;i--)
    {
        int c=1;
        for(int j=0;j<=i;j++)
        {
            if(arr[j]>arr[j+1])
            {
                swap(&arr[j],&arr[j+1],&c);
                swap(&index[j],&index[j+1],&c);
            }
        }
        if(c)
        return;
    }
}
void binary(int *arr,int *index,int n,int target)
{
    int start=0,end=n-1,index1=-1,index2=-1;
    while(start<=end)
    {
        int mid=start+(end-start)/2;
        if(arr[mid]==target)
        {
            index2=mid;
            start=mid+1; // 2 3 4 4 4 6
        }
        else if(arr[mid]<target)
        start=mid+1;
        else
        end=mid-1;
    }

    if(index2==-1)
    {
        printf("Element not present\n");
        return;
    }
    start=0; end=n-1;
    while(start<=end)
    {
        int mid=start+(end-start)/2;
        if(arr[mid]==target)
        {
            index1=mid;
            end=mid-1; // 2 3 4 4 4 6
        }
        else if(arr[mid]<target)
        start=mid+1;
        else
        end=mid-1;
    }

    printf("Element present at index: ");
    for(int i=index1;i<=index2;i++)
    printf("%d ",index[i]);
    
}
int main()
{
    int arr[100],n,index[100],target;

    printf("Enter array size : ");
    scanf("%d",&n);
    printf("Enter array elements : ");
    for(int i=0;i<n;i++)
    {
        scanf("%d",&arr[i]);
        index[i]=i;
    }

    sort(arr,index,n);

    printf("Enter target element : ");
    scanf("%d",&target);
    binary(arr,index,n,target);
    return 0;
}