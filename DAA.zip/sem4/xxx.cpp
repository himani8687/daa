#include <iostream>
#include <bits/stdc++.h>
using namespace std;
void arrive(string &id,stack<string>&s,unordered_map<string,int>&m)
{
    if(s.size()==10)
    {
        cout<<"Garage is full"<<endl;
        return;
    }
    s.push(id);
    cout<<"Car "<<id<<" arrived"<<endl;
}
void depart(string &id,stack<string>&s,unordered_map<string,int>&m)
{
    stack<string>t;
    bool flag=false;

    while(!s.empty()&&s.top()!=id)
    {
        t.push(s.top());
        s.pop();
    }
    if(s.empty())
    {
        cout<<"There is no car "<<id<<" in the garage"<<endl;
        flag=true;
    }
    else
    {
        cout<<"Car "<<id<<" departed. "<<"It was moved "<<m[s.top()]<<" time(s)"<<endl;
        s.pop();
    }
    

    while(!t.empty())
    {
        s.push(t.top());
        if(!flag)
        m[t.top()]++;
        t.pop();
    }
}
int main()
{
    string command,id;
    stack<string>s;
    unordered_map<string,int>m;
    while(1)
    {
        cout<<"Enter command(A for Arrival, D for Departure and E for Exit) : ";
        cin>>command;
        if(command=="E")
        return 0;
        cout<<"Enter plate no : ";
        cin>>id;
        if(command=="A")
        arrive(id,s,m);
        else if(command=="D")
        depart(id,s,m);
        else
        cout<<"Invalid Command\nPLs try again\n";
    }
    return 0;
}