// Normal Merge Sort
#include <stdio.h>
void merge(int *a,int start,int mid,int end)
{
    int t[end-start+1],c=0,i=start,j=mid+1;
    while(i<=mid&&j<=end)
    {
        if(a[i]<a[j])
        t[c++]=a[i++];
        else
        t[c++]=a[j++];
    }

    while(i<=mid)
    t[c++]=a[i++];
    while(j<=end)
    t[c++]=a[j++];

    c=0;
    for(int i=start;i<=end;i++)
    a[i]=t[c++];
}
void divide(int *a,int start,int end)
{
    if(start>=end)
    return;
    int mid=start+(end-start)/2;
    divide(a,start,mid);
    divide(a,mid+1,end); // 0 1 2 3 4
    merge(a,start,mid,end);
}
int main()
{
    int n,a[100];
    printf("Enter array size : ");
    scanf("%d",&n);
    printf("Enter array elements : ");
    for(int i=0;i<n;i++)
    scanf("%d",&a[i]);

    divide(a,0,n-1);

    printf("Sorted array : ");
    for(int i=0;i<n;i++)
    printf("%d ",a[i]);

    return 0;
}