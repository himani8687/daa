#include <stdio.h>
#include <stdlib.h>
typedef struct Node
{
    int data;
    struct Node *next;
}Node;
Node *adj[100];
Node *create(int x)
{
    Node *node=(Node *)malloc(sizeof(Node));
    node->data=x;
    node->next=NULL;
    return node;
}
void add(int x,int y)
{
    if(!adj[x])
    {
        adj[x]=create(y);
        return;
    }
    Node *t=adj[x];
    while(t->next)
    t=t->next;
    t->next=create(y);
}
void dfs(int *visit,int x)
{
    visit[x]=1;
    printf("%d ",x);
    Node *t=adj[x];
    while(t)
    {
        int neigh=t->data;
        if(!visit[neigh])
        dfs(visit,neigh);
        t=t->next;
    }
}
int main()
{
    printf("Enter no of vertices and edges : ");
    int e,v;
    scanf("%d%d",&v,&e);

    printf("Enter edges : ");
    for(int i=0;i<e;i++)
    {
        int src,dest;
        scanf("%d%d",&src,&dest);
        add(src,dest);
        add(dest,src);
    }

    int src;
    printf("Enter starting point : ");
    scanf("%d",&src);

    int visit[100];
    for(int i=1;i<=v;i++)
    visit[i]=0;


    dfs(visit,src);
}