#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define N 4
#define SIZE 16

int goal[N][N] = {
    {1, 2, 3, 4},
    {5, 6, 7, 8},
    {9,10,11,12},
    {13,14,15, 0}
};

// Directions: up, down, left, right
int dx[] = {-1, 1, 0, 0};
int dy[] = {0, 0, -1, 1};

typedef struct Node {
    int mat[N][N];
    int x, y;             // Blank tile position
    int cost, level;      // f = g + h
    struct Node* parent;  // For printing path
    struct Node* next;
} Node;

// Allocate and initialize a new node
Node* newNode(int mat[N][N], int x, int y, int newX, int newY, int level, Node* parent) {
    Node* node = (Node*)malloc(sizeof(Node));
    memcpy(node->mat, mat, sizeof(node->mat));

    // Move blank
    int temp = node->mat[x][y];
    node->mat[x][y] = node->mat[newX][newY];
    node->mat[newX][newY] = temp;

    node->x = newX;
    node->y = newY;
    node->level = level;
    node->cost = 0;
    node->parent = parent;
    node->next = NULL;
    return node;
}

// Manhattan distance heuristic
int calculateHeuristic(int mat[N][N]) {
    int dist = 0;
    for (int i = 0; i < N; ++i)
        for (int j = 0; j < N; ++j)
            if (mat[i][j] != 0) {
                int val = mat[i][j] - 1;
                int goalX = val / N;
                int goalY = val % N;
                dist += abs(i - goalX) + abs(j - goalY);
            }
    return dist;
}

// Print matrix
void printMatrix(int mat[N][N]) {
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j)
            if (mat[i][j] == 0)
                printf("   ");
            else
                printf("%2d ", mat[i][j]);
        printf("\n");
    }
    printf("-----------------------\n");
}

// Check if within bounds
int isSafe(int x, int y) {
    return x >= 0 && x < N && y >= 0 && y < N;
}

// Check if current state is goal
int isGoal(int mat[N][N]) {
    for (int i = 0; i < N; ++i)
        for (int j = 0; j < N; ++j)
            if (mat[i][j] != goal[i][j])
                return 0;
    return 1;
}

// Compare two matrices
int isSame(int a[N][N], int b[N][N]) {
    for (int i = 0; i < N; ++i)
        for (int j = 0; j < N; ++j)
            if (a[i][j] != b[i][j])
                return 0;
    return 1;
}

// Priority queue based on cost
void push(Node** head, Node* node) {
    if (!(*head) || node->cost < (*head)->cost) {
        node->next = *head;
        *head = node;
    } else {
        Node* curr = *head;
        while (curr->next && curr->next->cost <= node->cost)
            curr = curr->next;
        node->next = curr->next;
        curr->next = node;
    }
}

Node* pop(Node** head) {
    if (!(*head)) return NULL;
    Node* temp = *head;
    *head = (*head)->next;
    return temp;
}

// Print path from root to current
void printPath(Node* root) {
    if (root == NULL) return;
    printPath(root->parent);
    printMatrix(root->mat);
}

// Solve 15 puzzle using A* (branch and bound)
void solve(int initial[N][N], int x, int y) {
    Node* openList = NULL;

    Node* root = newNode(initial, x, y, x, y, 0, NULL);
    root->cost = calculateHeuristic(root->mat);
    push(&openList, root);

    int steps = 0;

    while (openList) {
        Node* current = pop(&openList);

        if (isGoal(current->mat)) {
            printf("Solved in %d steps!\n\n", current->level);
            printPath(current);
            return;
        }

        for (int i = 0; i < 4; ++i) {
            int newX = current->x + dx[i];
            int newY = current->y + dy[i];

            if (isSafe(newX, newY)) {
                Node* child = newNode(current->mat, current->x, current->y, newX, newY, current->level + 1, current);
                child->cost = child->level + calculateHeuristic(child->mat);
                push(&openList, child);
            }
        }
    }

    printf("No solution found.\n");
}

int main() {
    int initial[N][N] = {
        {1, 2, 3, 4},
        {5, 6, 0, 8},
        {9,10, 7,12},
        {13,14,11,15}
    };

    int x, y;
    for (int i = 0; i < N; ++i)
        for (int j = 0; j < N; ++j)
            if (initial[i][j] == 0)
                x = i, y = j;

    solve(initial, x, y);

    return 0;
}
