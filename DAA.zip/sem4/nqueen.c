#include <stdio.h>
void find(char queen[][100],int col[],int left[],int right[],int i,int n,int *c)
{
    if(i==n)
    {
        printf("Solution %d:\n",*c); (*c)++;
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<n;j++)
            {
                if(queen[i][j]=='.')
                printf("%c ",queen[i][j]);
                else
                printf("%c%d ",queen[i][j],i+1);
            }
            printf("\n");;
        }
        printf("\n");
        return;
        
    }
    for(int j=0;j<n;j++)
    {
        if(!col[j]&&!left[j-i+n-1]&&!right[i+j])
        {
            queen[i][j]='Q';
            col[j]=1;
            left[j-i+n-1]=1;
            right[i+j]=1;
            find(queen,col,left,right,i+1,n,c);
            queen[i][j]='.';
            col[j]=0;
            left[j-i+n-1]=0;
            right[i+j]=0;
        }
    }
}
int main()
{
    int n;
    printf("Enter no of queen : ");
    scanf("%d",&n);

    char queen[100][100];
    
    for(int i=0;i<n;i++)
    for(int j=0;j<n;j++)
    queen[i][j]='.';

    int col[100],left[100],right[100];
    for(int i=0;i<n;i++)
    col[i]=0;

    for(int i=0;i<2*n-1;i++)
    {
        left[i]=0;
        right[i]=0;
    }
    int c=1;
    find(queen,col,left,right,0,n,&c);
    return 0;
}