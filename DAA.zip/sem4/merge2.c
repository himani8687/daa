// Modified Merge Sort
#include <stdio.h>
void merge(int *a,int start,int x,int y,int end)
{
    int t[y-start+1],c=0,i=start,j=x+1;
    while(i<=x&&j<=y)
    {
        if(a[i]<a[j])
        t[c++]=a[i++];
        else
        t[c++]=a[j++];
    }
    while(i<=x)
    t[c++]=a[i++];
    while(j<=y)
    t[c++]=a[j++];

    int q[end-start+1],z=0; i=0,j=y+1;
    while(i<c&&j<=end)
    {
        if(t[i]<a[j])
        q[z++]=t[i++];
        else
        q[z++]=a[j++];
    }
    while(i<c)
    q[z++]=t[i++];
    while(j<=end)
    q[z++]=a[j++];

    z=0;
    for(int i=start;i<=end;i++)
    a[i]=q[z++];
}
void divide(int *a,int start,int end)
{
    if(start>=end)
    return;
    int x=start+(end-start)/3;
    int y=(x+1+end)/2;
    divide(a,start,x);
    divide(a,x+1,y); // 0 1 2 3 4 5    0 1 2 3 4 5 6   0 1 2 3 4 5 6 7
    divide(a,y+1,end);
    merge(a,start,x,y,end);
}
int main()
{
    int n,a[100];
    printf("Enter array size : ");
    scanf("%d",&n);
    printf("Enter array elements : ");
    for(int i=0;i<n;i++)
    scanf("%d",&a[i]);

    divide(a,0,n-1);

    printf("Sorted array : ");
    for(int i=0;i<n;i++)
    printf("%d ",a[i]);

    return 0;
}